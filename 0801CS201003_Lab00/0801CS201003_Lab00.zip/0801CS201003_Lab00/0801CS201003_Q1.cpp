#include <bits/stdc++.h>
using namespace std;

//hello class
class Hello
{
  public:
  Hello()
  {
    cout<<"Hello World";
  }
};

//driver code
int main()
{
  Hello h;
  return 0;
}