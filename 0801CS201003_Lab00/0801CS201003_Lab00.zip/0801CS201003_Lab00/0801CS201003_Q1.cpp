#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define fast ios_base::sync_with_stdio(false);cin.tie(NULL);

int main()
{
  double a,b,c;
  cin>>a>>b>>c;
  cout<<a+b+c<<"\n";

  return 0;
}